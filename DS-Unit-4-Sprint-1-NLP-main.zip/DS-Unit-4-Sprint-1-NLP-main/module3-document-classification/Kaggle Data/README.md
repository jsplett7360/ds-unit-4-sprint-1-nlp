# Kaggle Competition

Setup an inclass Kaggle Competition using the attached data. I generated the dataset from a personal project a few years backs. The notebook isn't super clean, but you can see how I gathered the data and generated the `ratingCategory` column.  Suggest adding the kaggle competition copy in this read me in the future as well. 

Benchmkark accuracy is minimum 75% max ever submitted by student is around 82% on private leaderboard.
